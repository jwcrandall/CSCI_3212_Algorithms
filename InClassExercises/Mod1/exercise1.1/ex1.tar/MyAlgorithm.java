
public class MyAlgorithm {

  public double findLargestDistance (Pointd[] points)
  {
    // INSERT YOUR CODE HERE:
  }

}
